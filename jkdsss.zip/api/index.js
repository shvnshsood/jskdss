const API_KEY = "44168605-2bec615a8e96f26fd4650aaa2";

const apiUrl = `https://pixabay.com/api/?key=${API_KEY}`